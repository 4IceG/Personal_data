-- Copyright 2020 Rafał Wabik /IceG/ Forum eko.one.pl user
-- Licensed to the public under the Apache License 3.0.

module("luci.controller.userserialn", package.seeall)

function index()
	entry({"admin", "status", "realtime", "userserial"}, call("usrsn")).leaf = true
end

function usrsn()
end
