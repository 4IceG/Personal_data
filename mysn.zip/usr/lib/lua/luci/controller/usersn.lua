-- Copyright 2020 Rafał Wabik /IceG/ Forum eko.one.pl user
-- Licensed to the public under the Apache License 3.0.

module("luci.controller.usersn", package.seeall)

function index()
	entry({"admin", "status", "realtime", "usersn"},
		call("sndisplay")).leaf = true
end

function sndisplay()
	local snslot = { }
	local snum = tostring(uci:get("mysection", "SerialNumber"))
	snslot["sn"] = snum
	luci.http.prepare_content("application/json")
	luci.http.write_json(sim)
end
